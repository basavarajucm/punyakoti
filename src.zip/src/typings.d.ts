/* SystemJS module definition */
declare var module: NodeModule;
declare var Appcodova: any;
declare var useCordovaYoutubePlayer: any;
declare var useMediaPlayerLink: any;
interface NodeModule {
  id: string;
}
