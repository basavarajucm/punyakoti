function Appcodova(url) {
    var url = url;
    var target = '_blank';
    var options = "location = yes";
    var ref = cordova.InAppBrowser.open(url, target, options);
    
    ref.addEventListener('loadstart', loadstartCallback);
    ref.addEventListener('loadstop', loadstopCallback);
    ref.addEventListener('loadloaderror', loaderrorCallback);
    ref.addEventListener('exit', exitCallback);

    function loadstartCallback(event) {
        console.log('Loading started: '  + event.url)
    }

    function loadstopCallback(event) {
        console.log('Loading finished: ' + event.url)
    }

    function loaderrorCallback(error) {
        console.log('Loading error: ' + error.message)
    }

    function exitCallback() {
        console.log('Browser is closed...')
    }
}
function useCordovaYoutubePlayer(videoUrl){
    YoutubeVideoPlayer.openVideo(videoUrl, function(result) { console.log('YoutubeVideoPlayer result = ' + result); });
}
function useMediaPlayerLink(url){
    var options = {
        successCallback: function() {
          console.log("Audio was closed without error.");
        },
        errorCallback: function(errMsg) {
          console.log("Error! " + errMsg);
        },
        orientation: 'landscape'
    };
    window.plugins.streamingMedia.playAudio(url, options);
}
document.addEventListener("deviceready", function(){
    window.FirebasePlugin.getToken();
    window.FirebasePlugin.subscribe("punyakotiapptopic");
    /*window.FirebasePlugin.onTokenRefresh();
    window.FirebasePlugin.onNotificationOpen();*/    
}, false);