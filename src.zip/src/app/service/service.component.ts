import { Component } from '@angular/core';

@Component({
  selector: 'service-root',
  templateUrl: './service.component.html',
  styleUrls : ['./service.component.css']
})
export class ServiceComponent {
  title = 'Punyakoti app';
  /*isShown = true;
  test(drawer: any){
    drawer.toggle();
  }*/
}
