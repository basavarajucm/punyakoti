import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {AppService} from '../app.service';
@Component({
  selector: 'articlesdetails-root',
  templateUrl: './articledetails.component.html',
  styleUrls : ['./articles.component.css']
})
export class ArticlesdetailsComponent {
  id: number;
  articledtl =[];
  isResponse:boolean = true;
  @Input() rating: number;
  @Input() itemId: number;
  @Output() ratingClick: EventEmitter<any> = new EventEmitter<any>();
  inputName: string;
  comments:string;
  response:boolean=false;
  constructor(private route: ActivatedRoute,public appService: AppService) {}
  ngOnInit() {

    this.inputName = this.itemId + '_rating';

    this.route.params.subscribe(params => { 
      this.id = +params['id']; 
    });
    this.appService.getArticleDetails(this.id).subscribe(data => {
      this.articledtl = data;
      this.isResponse = (this.articledtl.length > 0) ? true : false;
    });
  }
  onClick(rating: number): void {
    this.rating = rating;
    this.ratingClick.emit({
      itemId: this.itemId,
      rating: rating
    });
    console.log(rating)
}
saveComments()
{
  console.log(this.comments);
  console.log(this.id);
  console.log(this.rating);
  this.appService.saveComments(this.id,this.rating,this.comments)
  .subscribe(data=>{
    console.log(data);
    this.response=data.status;
    console.log(this.response);
  });
}
}
