import { Component } from '@angular/core';
import {AppService} from '../app.service';
import {Router} from '@angular/router';
@Component({
  selector: 'articles-root',
  templateUrl: './articles.component.html',
  styleUrls : ['./articles.component.css']
})
export class ArticlesComponent {
  articles = [];
  articledtl : object;
  isResponse:boolean = true;
 
  constructor(public appService: AppService,private router: Router) { }
  articleDetail(id){
  
    this.router.navigate(['/articledetails',id]);
  }
  ngOnInit() {
    this.appService.getArticles().subscribe(data => {
      this.articles = data; 
      
      this.isResponse = (this.articles.length > 0) ? true : false;
    });
   
   /* this.appService.getRatings(this.articleID).subscribe(data=>{
      console.log(data);
    });*/
  }
}
