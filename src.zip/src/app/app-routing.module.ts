import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ServiceComponent } from './service/service.component';
import { AboutComponent } from './about/about.component';
import { SymptomsComponent } from './symptoms/symptoms.component';
import { ReviewComponent } from './review/review.component';
import { CampsComponent } from './camps/camps.component';
import { ArticlesComponent } from './articles/articles.component';
import { ArticlesdetailsComponent } from './articles/articledetails.component';
import { VidioComponent } from './video/video.component';
import { ContactComponent } from './contact/contact.component';
import { ShareComponent } from './share/share.component';
const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    { path: 'service', component: ServiceComponent },
    { path: 'camp', component: CampsComponent },
    { path: 'symptoms', component: SymptomsComponent },
    { path: 'articles', component: ArticlesComponent },
    { path: 'review', component: ReviewComponent },
    { path: 'articledetails/:id', component: ArticlesdetailsComponent },
    { path: 'video', component: VidioComponent },
    { path: 'contact', component: ContactComponent},
    {path :'share', component:ShareComponent}
  ];
@NgModule({
    imports: [ RouterModule.forRoot(routes) ],
    exports: [ RouterModule ]
})
export class AppRoutingModule {

}