import { Component } from '@angular/core';
import {AppService} from '../app.service';
@Component({
  selector: 'camp-root',
  templateUrl : './camps.component.html',
  styleUrls : ['./camps.component.css'],
  //providers: [AppService]
})
export class CampsComponent {
  camps = [];
  isResponse:boolean = true;
  constructor(private appService: AppService) { }
  ngOnInit() {
    this.appService.getCampDetals().subscribe(data => {
      this.camps = data;
      this.isResponse = (this.camps.length > 0) ? true : false;
    });
  }
}
