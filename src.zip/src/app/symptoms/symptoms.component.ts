import { Component } from '@angular/core';

@Component({
  selector: 'symptoms-root',
  templateUrl: './symptoms.component.html',
  styleUrls : ['./symptoms.component.css']
})
export class SymptomsComponent {
  title = 'Punyakoti app';
  /*isShown = true;
  test(drawer: any){
    drawer.toggle();
  }*/
}
