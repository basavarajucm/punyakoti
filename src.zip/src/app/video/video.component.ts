import { Component } from '@angular/core';
import {AppService} from '../app.service';

@Component({
  selector: 'video-root',
  templateUrl: './video.component.html',
  styleUrls : ['./video.component.css']
})
export class VidioComponent {
  title = 'Punyakoti app';
  videos = [];
  liveVideo = [];
  isResponse:boolean = true;
  isLive:boolean = false;
  constructor(public appService: AppService) { }
  ngOnInit() {
    this.appService.getVideos().subscribe(data => {
      this.videos = data; console.log(this.videos);
      this.isResponse = (this.videos.length > 0) ? true : false;
      this.isLive = (this.videos[0].type == 'live') ? true : false;
      if(!this.isLive) {
        console.log('no live videos, setting timeout');
        setTimeout(() => { this.getLive(); }, 30000);
      }

    });
  }

  getLive() {
    console.log('getting live');
    this.appService.getLive().subscribe(data => {
      if(data.length > 0) {
        this.liveVideo = data[0];
        this.videos.unshift(this.liveVideo);
        console.log(this.videos);
      } else {
        setTimeout(() => { this.getLive(); }, 30000);
      }
    });
  }
}
