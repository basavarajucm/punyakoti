import { Component,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
//import {ShareComponent} from './share/share.Component'

declare let window:any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Punyakoti app';
  animal: string;
  name: string;

  constructor(public dialog: MatDialog){}
  /*isShown = true;
  test(drawer: any){
    drawer.toggle();
  }
  opneModel()
  {
    console.log('hello');
  }*/
  openDialog(): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '250px',
      data: {name: this.name, animal: this.animal}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }
  shareApp()
  {
    window.plugins.socialsharing.share(
    'PunyaKoti App native shareapps',
    null /* img */,
    null, 
    "https://play.google.com/store/apps/details?id=in.punyakoti.app" /* url */, 
   
    function(errormsg){alert("Error: Cannot Share")}
    );
  }
}
@Component({
  selector: 'app-share',
  templateUrl: './share/share.component.html',
  styleUrls: ['./share/share.component.css']
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
  callWhatsapp()
  {
    window.plugins.socialsharing.shareViaWhatsApp('Message via WhatsApp',
    null /* img */,
    "https://play.google.com/store/apps/details?id=in.punyakoti.app" /* url */, 
    null, 
    function(errormsg){alert("Error: Cannot Share")}
    );
  }
  callFaceBook()
  {
    window.plugins.socialsharing.shareViaFacebookWithPasteMessageHint('PunyaKoti App',
    null /* img */,
    "https://play.google.com/store/apps/details?id=in.punyakoti.app" /* url */, 
    null, 
    function(errormsg){alert("Error: Cannot Share")}
    );
  }
 

}