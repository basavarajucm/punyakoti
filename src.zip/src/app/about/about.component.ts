import { Component } from '@angular/core';

@Component({
  selector: 'about-root',
  templateUrl: './about.component.html',
  styleUrls : ['./about.component.css']
})
export class AboutComponent {
  title = 'Punyakoti app';
  /*isShown = true;
  test(drawer: any){
    drawer.toggle();
  }*/
}
