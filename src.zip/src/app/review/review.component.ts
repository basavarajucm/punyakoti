import { Component } from '@angular/core';
import {AppService} from '../app.service';
import {Router} from '@angular/router';
@Component({
  selector: 'review-root',
  templateUrl : './review.component.html',
  styleUrls : ['./review.component.css']
})
export class ReviewComponent {
  title = 'Punyakoti app';
  response:any;
  isSuccess :boolean = false;
  constructor(private appService: AppService,private router: Router) { }
  submitReview(data){
    this.appService.saveReview(data).subscribe(data => {
        this.response = data;
        if(this.response.status == 'success'){
          this.isSuccess = true;
          setTimeout(()=>{  this.router.navigate(['/home']); },3000);
        }
    } );
  }
}
