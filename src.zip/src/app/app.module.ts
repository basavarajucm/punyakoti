import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';

import {FlexLayoutModule} from '@angular/flex-layout';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {MatInputModule} from '@angular/material/input';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
//import 'hammerjs';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatDialogModule} from '@angular/material/dialog';

import {AppService} from './app.service';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { ServiceComponent } from './service/service.component';
import { AboutComponent } from './about/about.component';
import { SymptomsComponent } from './symptoms/symptoms.component';
import { ReviewComponent } from './review/review.component';
import { CampsComponent } from './camps/camps.component';
import { ArticlesComponent } from './articles/articles.component';
import { ArticlesdetailsComponent } from './articles/articledetails.component';
import { VidioComponent } from './video/video.component';
import { ContactComponent } from './contact/contact.component';
import { ShareComponent } from './share/share.component';
import {DialogOverviewExampleDialog} from './app.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ServiceComponent,
    AboutComponent,
    SymptomsComponent,
    ReviewComponent,
    CampsComponent,
    ArticlesComponent,
    ArticlesdetailsComponent,
    VidioComponent,
    ContactComponent,
    ShareComponent,
    DialogOverviewExampleDialog
  ],
  imports: [
    BrowserModule,
    HttpModule,
    MatSidenavModule,
    MatListModule,
    MatToolbarModule,
    MatCardModule,
    MatIconModule,
    MatGridListModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    AppRoutingModule,
    MatExpansionModule,
    MatInputModule,
    MatButtonModule, 
    MatCheckboxModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    MatDialogModule
     
  ],
  providers: [AppService],
  entryComponents:[DialogOverviewExampleDialog, ShareComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
