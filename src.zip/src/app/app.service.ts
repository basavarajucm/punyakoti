import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class AppService {
  constructor(private http: Http) { }
  
  test(camp:any){
    console.log(camp);
  }
  serverUrl = 'https://punyakotiapp.caremap.in';
  campUrl = this.serverUrl+'/welcome/getCamps';
  articleUrl = this.serverUrl+'/welcome/getArticles';
  videoUrl = this.serverUrl+'/welcome/getVideos';
  saveReviewUrl = this.serverUrl+'/welcome/saveReview';
  articleDetailUrl :string;
  liveUrl = this.serverUrl+'/welcome/getLive';
  saveCommentUrl=this.serverUrl+'/welcome/saveComments';
  getCommentsUrl=this.serverUrl+'/welcome/getComments';

  getCampDetals(){
    return this.http.get(this.campUrl).map((response:Response) => response.json());
  };
  getArticles(){
    return this.http.get(this.articleUrl).map((response:Response) => response.json());
  };
  getArticleDetails(id:number){
    this.articleDetailUrl = this.serverUrl+'/welcome/getArticleDetails/'+id;
    return this.http.get(this.articleDetailUrl).map((response:Response) => response.json());
  }
  getVideos(){
    return this.http.get(this.videoUrl).map((response:Response) => response.json());
  }
  saveReview(data){
    return this.http.post(this.saveReviewUrl,data).map((response:Response) => response.json());
  }
  playArticle(url:any){ // streaming media plugin to play audios
    new useMediaPlayerLink(url);
  }
  article(url:any){ //in app browser plugin to open link
    new Appcodova(url);
  }
  useYoutubePlayer(videoUrl:any){ // youtube player to play youtube videos
    new useCordovaYoutubePlayer(videoUrl);
  }
  getLive(){
    return this.http.get(this.liveUrl).map((response:Response) => response.json());
  }

  saveComments(id:number,rating:number,comments:string)
  {
    return this.http.post(this.saveCommentUrl,JSON.stringify({id:id,rating:rating,comments:comments})).map((response:Response)=>response.json());
  }
 /* getRatings(id:number)
  {
    console.log(id);
    return this.http.get(this.getCommentsUrl,JSON.stringify({id:id})).map((response:Response)=>response.json());
  }*/
}
